from flask import Flask, render_template, request
import pymysql

app = Flask(__name__)
db = pymysql.connect("localhost", "root", "", "db")

@app.route('/tnxsubscribe', methods = ['POST'])
def post_email():
  if request.method =='POST':
    info = request.form
    email = info['subemail']
    cursor = db.cursor()
    try:
      cursor.execute("INSERT INTO `subscribe email`(`email`) VALUES (%s)",(email))
      db.commit()
    except:
      db.rollback()
    cursor.close()
  return render_template('tnxsubscribe.html')     


@app.route('/tnxmessage', methods = ['POST'])
def post_messageinfo():
  if request.method =='POST':
    info = request.form
    qname = info['questionname']
    qemail = info['questionemail']
    qmsg = info['question']
    cursor = db.cursor()
    cursor.execute("INSERT INTO `message`(`name`,`email`,`message`) VALUES (%s,%s,%s)",(qname,qemail,qmsg))
    db.commit()
    cursor.close()
    return render_template('tnxmessage.html')

@app.route('/purchase')
def show():
  return render_template('purchase.html')

@app.route('/tnxpurchase', methods = ['POST'])
def post_purchase():
  if request.method =='POST':
    info = request.form
    pname = info['purchasename']
    pemail = info['purchaseemail']
    pquantity = info['purchasequantity']
    cursor = db.cursor()
    cursor.execute("INSERT INTO `purchase`(`name`,`email`,`quantity`) VALUES (%s,%s,%s)",(pname,pemail,pquantity))
    db.commit()
    cursor.close()
    return render_template('tnxpurchase.html')

@app.route("/")
def index():
  return render_template('abstract.html')

if __name__ == '__main__':
  app.run(debug=True)
