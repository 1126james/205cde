window.addEventListener('load', run);
function run() {setTimeout(redir, 3000)};
function redir() {window.location.href="http://127.0.0.1:5000/"};
