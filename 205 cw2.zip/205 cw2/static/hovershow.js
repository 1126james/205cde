$(document).ready(function(){
  $('#firstcontain p').hide();
  $('#secondcontain p').hide();
  $('#tab3img1').hover(function(){   //This wont delay...
    $('#firstcontain p').show(1000); //doesnt work if change show()/hide() to fadeIn()/fadeOut()
  });
  $('#tab3img1').mouseleave(function(){
    $('#firstcontain p').hide(1000);
  });
  $('#tab3img2').mouseover(function(){
    $('#secondcontain p').show(1000);
  });
  $('#tab3img2').mouseleave(function(){
    $('#secondcontain p').hide(1000);
  });
});
