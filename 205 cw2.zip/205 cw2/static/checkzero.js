function checkzero() {
  var x = document.forms["purchase"]["purchasequantity"].value;
  if (x <= 0) {
    alert("Your purchasing quantity can not be 0 or less than 0!");
    return false;
  }
  return true;
}
